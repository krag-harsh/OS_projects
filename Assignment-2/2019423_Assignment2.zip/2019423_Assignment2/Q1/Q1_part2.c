/* Name: Harsh Kumar Agarwal
   Roll_Number: 2019423 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h> 
#include <sys/types.h>
#include <sys/wait.h>
#include <pthread.h> 

int n=10;      //global variable

void *workinthread(void *arg)
{
   printf("Value of n on starting of child thread = %d\n",n);
   while(n>-90)
   //for(int i=0;i<90;i++)
   {
      n--;
      printf("%d\n",n);
   }
   printf("Final value of n inside child thread: %d\n\n", n);

}


int main()
{

   pthread_t newthread;
   pthread_create(&newthread, NULL, workinthread, NULL);
   //pthread_exit(NULL);

   printf("Value of n on starting of parent process = %d\n",n);
   while (n<100)
   //for(int j=0;j<90;j++)
   {
      n++;
      printf("%d\n",n);
   }

   printf("Final value of n inside parent process = %d\n\n", n);

   pthread_join(newthread,NULL);
   
   return 0;
}
