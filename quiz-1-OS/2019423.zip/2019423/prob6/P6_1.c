//#include <stdio.h>

int main()
{
    char name[]="Harsh";  //here we are creating an char array which will store the data(name) in main memory

    //printf("Name= %s\n",name);
    return 0;
    
}

